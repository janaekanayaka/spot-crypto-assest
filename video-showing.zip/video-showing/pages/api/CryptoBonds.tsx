import React from 'react'

const CryptoBonds = () => {
    return (
        <div>

        </div>
    )
}

export default CryptoBonds
