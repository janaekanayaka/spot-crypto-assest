import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Signal {
    id: number;
    symbol: string;
    name: string;
    price: number;
    signal: string;
    timestamp: string;
}

const CryptoFutureSignals: React.FC = () => {
    const [signals, setSignals] = useState<Signal[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        // Fetch data from Coinology API
        axios
            .get<Signal[]>('https://coinology.eu/en/api/v1/signals/SELECTION/')
            .then((response) => {
                setSignals(response.data);
                setLoading(false);
            })
            .catch((error) => {
                console.error('Error fetching the signals', error);
                setError('Failed to fetch data');
                setLoading(false);
            });
    }, []);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div>
            <h2>Crypto Future Signals</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Symbol</th>
                        <th>Name</th>
                        <th>Price (USD)</th>
                        <th>Signal</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    {signals.map((signal) => (
                        <tr key={signal.id}>
                            <td>{signal.id}</td>
                            <td>{signal.symbol}</td>
                            <td>{signal.name}</td>
                            <td>{signal.price}</td>
                            <td>{signal.signal}</td>
                            <td>{new Date(signal.timestamp).toLocaleString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default CryptoFutureSignals;
