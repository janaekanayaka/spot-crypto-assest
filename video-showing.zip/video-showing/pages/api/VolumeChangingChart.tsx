import React, { useEffect } from 'react';
import * as echarts from 'echarts';

const VolumeChangingChart = () => {
    useEffect(() => {
        const chartDom = document.getElementById('main') as HTMLDivElement;
        if (!chartDom) return;

        const myChart = echarts.init(chartDom);

        const fetchCoinData = async () => {
            try {
                const response = await fetch(
                    'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=volume_desc&per_page=10&page=1&sparkline=false'
                );
                const data = await response.json();
                renderChart(data);
            } catch (error) {
                console.error('Error fetching the coin data:', error);
            }
        };

        const renderChart = (coinData: any) => {
            const option: echarts.EChartOption = {
                title: {
                    text: 'Top 10 Cryptocurrencies by Volume',
                },
                tooltip: {
                    trigger: 'axis',
                },
                xAxis: {
                    type: 'category',
                    data: coinData.map((coin: any) => coin.name),
                    name: 'Coin',
                },
                yAxis: {
                    type: 'value',
                    name: 'Volume',
                },
                series: [
                    {
                        data: coinData.map((coin: any) => coin.total_volume),
                        type: 'bar',
                        label: {
                            show: true,
                            position: 'top',
                            formatter: '{b}: ${c}',
                        },
                    },
                ],
            };

            myChart.setOption(option);
        };

        fetchCoinData();

        // Cleanup function to dispose of the chart when the component unmounts
        return () => {
            myChart.dispose();
        };
    }, []);

    return <div id="main" style={{ width: '100%', height: '400px' }}></div>;
};

export default VolumeChangingChart;
