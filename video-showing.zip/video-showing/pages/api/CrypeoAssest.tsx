import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Define the type for the crypto data
interface Crypto {
    id: string;
    name: string;
    current_price: number;
}

const CryptoAsset: React.FC = () => {
    // Use an array of Crypto objects or null if not fetched
    const [cryptoData, setCryptoData] = useState<Crypto[] | null>(null);

    useEffect(() => {
        // Fetch cryptocurrency details from a public API
        axios
            .get<Crypto[]>('https://api.coingecko.com/api/v3/coins/markets', {
                params: {
                    vs_currency: 'usd',
                    ids: 'bitcoin,ethereum,ripple,litecoin', // Adjust the ids according to your needs
                },
            })
            .then((response) => {
                setCryptoData(response.data);
            })
            .catch((error) => {
                console.error('Error fetching the cryptocurrency data', error);
            });
    }, []);

    // Prepare the data for Recharts
    const prepareChartData = () => {
        if (!cryptoData) return [];

        return cryptoData.map((crypto: Crypto) => ({
            name: crypto.name,
            price: crypto.current_price,
        }));
    };

    return (
        <ResponsiveContainer width="100%" height={400}>
            <LineChart
                data={prepareChartData()}
                margin={{
                    top: 5, right: 30, left: 20, bottom: 5,
                }}
            >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="price" stroke="#8884d8" activeDot={{ r: 8 }} />
            </LineChart>
        </ResponsiveContainer>
    );
};

export default CryptoAsset;
