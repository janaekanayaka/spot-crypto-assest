import React, { useEffect, useState } from 'react';

interface Coin {
    id: string;
    name: string;
    symbol: string;
    current_price: number;
    price_change_percentage_24h: number;
    price_change_percentage_7d_in_currency?: number;
    market_cap: number;
    total_volume: number;
}

const BestSpotCoins = () => {
    const [coins, setCoins] = useState<Coin[]>([]);  // Explicitly typing the state
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCoins = async () => {
            try {
                const response = await fetch(
                    'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=volume_desc&per_page=100&page=1&sparkline=false'
                );
                const data: Coin[] = await response.json();  // Type the fetched data
                setCoins(data);
            } catch (error) {
                console.error('Error fetching the coin data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchCoins();
    }, []);

    if (loading) {
        return <p>Loading...</p>;
    }

    return (
        <div>
            <h2>Top 50 Cryptocurrencies by Volume</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Symbol</th>
                        <th>Price</th>
                        <th>24H Change</th>
                        <th>7D Change</th>
                        <th>Market Cap</th>
                        <th>24H Volume</th>
                    </tr>
                </thead>
                <tbody>
                    {coins.map((coin) => (
                        <tr key={coin.id}>
                            <td>{coin.name}</td>
                            <td>{coin.symbol.toUpperCase()}</td>
                            <td>${coin.current_price.toFixed(2)}</td>
                            <td
                                style={{
                                    color: coin.price_change_percentage_24h >= 0 ? 'green' : 'red',
                                }}
                            >
                                {coin.price_change_percentage_24h.toFixed(2)}%
                            </td>
                            <td
                                style={{
                                    color: coin.price_change_percentage_7d_in_currency >= 0 ? 'green' : 'red',
                                }}
                            >
                                {coin.price_change_percentage_7d_in_currency?.toFixed(2) || 'N/A'}%
                            </td>
                            <td>${coin.market_cap.toLocaleString()}</td>
                            <td>${coin.total_volume.toLocaleString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default BestSpotCoins;
