import Image from "next/image";
import { Inter } from "next/font/google";
import CryptoAsset from "./api/CrypeoAssest";
import CryptoFutureSignals from "./api/CryptoFutureSignals";
import BestSpotCoins from "./api/BestSpotCoins";
import VolumeChangingChart from "./api/VolumeChangingChart";

const inter = Inter({ subsets: ["latin"] });

const categories = ["All", "Basics", "Market Analaysis", "Spot trading", "Future Trading", "Candlestic patterns", "Market analysic", "Indicators", "Block Chain", "Whales News"];

const videoData = [
  { title: "I CREATED A BOT USING CHATGPT FOR ARBITRAGE UNISWAP", channel: "Robert_Web3bot", views: "12K views", time: "3 weeks ago", thumbnail: "/binance.jpg" },
  { title: "Mix - Dulan ARX - Mandire Hade Official Music Video", channel: "Sanjula Himala, Dulan ARX, D Brothers", views: "", time: "", thumbnail: "/binance.jpg" },
  { title: "මොකද වෙන්නේ | What's up? | Mokada Wenne", channel: "Vini Productions", views: "1.6M views", time: "4 days ago", thumbnail: "/binance.jpg" },
  { title: "MATHEE SONG", channel: "TRENDING", views: "49K views", time: "2 weeks ago", thumbnail: "/binance.jpg" },
];

export default function Home() {
  return (
    <>
      <div className="bg-gray-900 text-white min-h-screen">
        <header className="bg-gray-800 p-4 sticky top-0 z-10">
          <nav className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Sl Binance Plus</h1>
            <input
              type="text"
              placeholder="Search..."
              className="bg-gray-700 px-4 py-2 rounded-full text-sm w-1/3"
            />
            <div className="flex space-x-4">
              <button className="bg-gray-700 p-2 rounded-full">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
              </button>
              <button className="bg-gray-700 p-2 rounded-full">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
              </button>
            </div>
          </nav>
        </header>
        <div className="flex overflow-x-auto whitespace-nowrap py-4 px-6 bg-gray-800 border-b border-gray-700">
          {categories.map((category, index) => (
            <button key={index} className="px-3 py-1 mr-2 bg-gray-700 rounded-full text-sm hover:bg-gray-600">
              {category}
            </button>
          ))}
        </div>
        <main className={`flex flex-col p-6 ${inter.className}`}>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {videoData.map((video, index) => (
              <div key={index} className="bg-gray-800 rounded-lg overflow-hidden">
                <div className="relative aspect-w-16 aspect-h-9 bg-gray-700">
                  <Image src={video.thumbnail} alt={video.title} layout="fill" objectFit="cover" />
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 px-2 py-1 text-xs rounded">
                    {video.time}
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-sm">{video.title}</h3>
                  <p className="text-xs text-gray-400 mt-1">{video.channel}</p>
                  <p className="text-xs text-gray-400">{video.views} • {video.time}</p>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
      <div>
        <VolumeChangingChart />
      </div>
      <div>
        <CryptoAsset />
      </div>
      <div>
        <CryptoFutureSignals />
      </div>
      <div>
        <BestSpotCoins />
      </div>

    </>

  );
}